<?php $__env->startSection('title', 'Edit Medicine'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 mx-auto mt-3">
            <div class="card">
                <div class="card-header card-header-bg">Edit Medicine Profile</div>
                <div class="card-body">
                    <?php if(count($errors) > 0): ?>
                    <p class="alert alert-danger mb-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                    <?php endif; ?>
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                    <?php endif; ?>
                    <form method="POST" action=" <?php echo e(route('medAlert.update', $med_alert->id)); ?> ">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <label for="med_id">Medicine ID</label>
                        <div class="form-row">
                            <div class="col">
                                <input type="text" class="form-control" name="med_id" value="<?php echo e($med_alert->med_id); ?>"
                                    disabled>
                            </div>

                            <div class="col">

                            </div>
                        </div>


                        <div class="form-group mt-3">
                            <label for="gender">Gender</label>
                            <select class="form-control" id="gender" name="alert_gender">
                                <?php if($med_alert->alert_gender == 'both'): ?>
                                <option selected ="selected">Both</option>
                                <?php else: ?>
                                <option>Both</option>
                                <?php endif; ?>
                                <?php if($med_alert->alert_gender == 'Male'): ?>
                                <option selected ="selected">Male</option>
                                <?php else: ?>
                                <option>Male</option>
                                <?php endif; ?>
                                <?php if($med_alert->alert_gender == 'Female'): ?>
                                <option selected ="selected">Female</option>
                                <?php else: ?>
                                <option>Female</option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <label for="alert_range">Age Range</label>
                        <div class="form-row">
                            <div class="col">
                                <input type="number" class="form-control" name="age_range_low" placeholder="Low"
                                    value="<?php echo e($med_alert->age_range_low); ?>">
                            </div>

                            <div class="col">
                                <input type="number" class="form-control" name="age_range_high" placeholder="High"
                                    value="<?php echo e($med_alert->age_range_high); ?>">
                            </div>
                        </div>

                        <div class="form-row mt-3">
                            <div class="col">
                                <label for="alert_range">Alert Range</label>
                                <input type="number" class="form-control" name="alert_range"
                                    value="<?php echo e($med_alert->alert_range); ?>">
                            </div>

                            <div class="col">
                                <label for="med_unit">Medicine Unit</label>
                                <input type="text" class="form-control" name="med_unit" value="<?php echo e($med_alert->med_unit); ?>">
                            </div>
                        </div>

                        <div class="form-row mt-3">
                            <div class="col">
                                <label for="max_duration">Max Duration</label>
                                <input type="number" class="form-control" name="max_duration"
                                    value="<?php echo e($med_alert->max_duration); ?>">
                            </div>

                            <div class="col">
                                <label for="duration_unit">Duration Unit</label>
                                <input type="text" class="form-control" name="duration_unit"
                                    value="<?php echo e($med_alert->duration_unit); ?>">
                            </div>
                        </div>

                        <div class="form-group mt-3">
                            <label for="alert_for">Alert For</label>
                            <input type="text" class="form-control" name="alert_for" value="<?php echo e($med_alert->alert_for); ?>">
                        </div>

                        <button type="submit" class="btn btn-primary">Apply Changes</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/medicine/alert/edit.blade.php ENDPATH**/ ?>