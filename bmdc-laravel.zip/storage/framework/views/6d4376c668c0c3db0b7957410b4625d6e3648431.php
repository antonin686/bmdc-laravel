<?php $__env->startSection('title', 'All medicine'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mt-3">
   
        <div title="Generic">
             <div class="h1 text-secondary mb-3 pb-3"><?php echo e($generic->generic_name); ?></div>
        </div>
        
        <a class="btn btn-info mb-3" href="<?php echo e(route('medicine.genericBased', $generic->id)); ?>">View All Brand Names</a>
        <?php $__currentLoopData = $generic_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($value): ?>
        <div class="col-md-12 m-0 p-0">
            <div class="card mb-3 mt-3">
                <div class="card-body bg-dark text-white"><?php echo e($key); ?></div>
                <div class="card-body">
                <?php echo nl2br($value); ?>

                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/medicine/generic/show.blade.php ENDPATH**/ ?>