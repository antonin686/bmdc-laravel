<?php $__env->startSection('title', 'Generic Based Brand List'); ?>

<?php $__env->startSection('subcontent'); ?>
<div class="row">
    <div class="col-md-12 mx-auto mt-3">
        <div class="card">

            <div class="card-body">
                <div class="h2 m-3 p-3">
                    <?php echo e($meds->generic_name); ?> <small class="text-secondary">Available Brand Names</small>
                </div>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-responsive-sm table-hover" id="table">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Brand Name</th>
                                    <th scope="col">Dosage</th>
                                    <th scope="col">Company</th>
                                    <th scope="col">Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $meds->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="<?php echo e($med->id); ?>">
                                    <td><?php echo e($med->id); ?></td>
                                    <td><?php echo e($med->brand_name); ?> <small><?php echo e($med->strength); ?></small> </td>
                                    <td><?php echo e($med->dosage_form); ?></td>
                                    <td><?php echo e($med->company); ?></td>
                                    <td><?php echo e($med->price); ?> tk</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

$(document).ready(function() {
    $('#table').DataTable();
    $('#table').on('click', 'tr', (event) => {
        var id = $(event.currentTarget).attr("id");
        if (id != null) {
            window.location.href = `/publicMedicine/${id}`;
        }
    });
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medicine', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/public/medicine/genericBased.blade.php ENDPATH**/ ?>