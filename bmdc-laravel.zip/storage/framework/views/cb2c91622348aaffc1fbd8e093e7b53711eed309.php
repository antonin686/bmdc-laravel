<?php $__env->startSection('title', 'Doctor Application Authorization'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <?php if(count($errors) > 0): ?>
                    <p class="alert alert-danger mb-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                    <?php endif; ?>
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                    <?php endif; ?>
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="nid">NID</label>
                            <input type="text" class="form-control" name="nid" value="<?php echo e($app->nid); ?>">
                        </div>

                        <label for="registration_id">Registration Number</label><br>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" name="registration_id" id="registration_id">
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="button"
                                    id="generate_id">Generate</button>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="full_name">Full Name</label>
                            <input type="text" class="form-control" name="full_name" value="<?php echo e($app->full_name); ?>">
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e($app->email); ?>">
                        </div>

                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="text" class="form-control" name="phone" value="<?php echo e($app->phone); ?>">
                        </div>

                        <div class="form-group">
                            <label for="basic_degree">Basic Degree</label>
                            <input type="text" class="form-control" name="basic_degree"
                                value="<?php echo e($app->basic_degree); ?>">
                        </div>

                        <div class="form-group">
                            <label for="advance_degree">Advance Degree</label>
                            <input type="text" class="form-control" name="advance_degree"
                                value="<?php echo e($app->advance_degree); ?>">
                        </div>

                        <div class="form-group">
                            <label for="speciality">Speciality</label>
                            <input type="text" class="form-control" name="speciality" value="<?php echo e($app->speciality); ?>">
                        </div>

                        <div class="form-group">
                            <label for="work_place">Work Place</label>
                            <input type="text" class="form-control" name="work_place" value="<?php echo e($app->work_place); ?>">
                        </div>

                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" name="username">
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password">
                        </div>

                        <input type="hidden" name="img_path" value="<?php echo e($app->img_path); ?>">

                        <button type="submit" class="btn btn-primary">Approve</button>
                        <button type="button" class="btn btn-danger">Reject</button>
                    </form>

                </div>
                <div class="col-md-4 mx-auto m-3">
                    <div class="card">
                        <img src="<?php echo e($app->img_path); ?>" class="card-img-top" alt="img">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {

    $("#generate_id").click(function() {
        generateDoctorID();
    });

    function generateDoctorID(id) {

        $.ajax({
            url: '/ajax/generateDoctorID',
            method: "GET",
            dataType: "json",
            success: function(result) {
                //console.log(result);
                $("#registration_id").val(result);
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/application/doctor/show.blade.php ENDPATH**/ ?>