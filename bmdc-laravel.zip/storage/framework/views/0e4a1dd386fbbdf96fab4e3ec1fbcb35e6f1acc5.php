<?php $__env->startComponent('mail::message'); ?>
# Sorry <?php echo e($data->name); ?> ,
Your Application For Doctor Authorization Has Beed Rejected <br> <br>
Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/emails/doctorReject.blade.php ENDPATH**/ ?>