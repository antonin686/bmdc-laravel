<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="display-1 text-secondary center-screen mx-auto">
        <div class="row">
            BMDC<div class="display-4 mt-4">(Prototype)</div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>