<?php $__env->startSection('title', 'Message'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card">

            <div class="card-body">
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>

                <div class="form-row">

                    <div class="col">
                        <a class="btn btn-info" href="<?php echo e(route('medAlert.show', session()->get('id'))); ?>">Medicine Alert
                            Profile</a>
                    </div>

                    <div class="col">
                        <a class="btn btn-primary" href="<?php echo e(route('medAlert.index')); ?>">Medicine Alert List</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/medicine/alert/message.blade.php ENDPATH**/ ?>