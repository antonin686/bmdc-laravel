<?php $__env->startSection('title', 'All Prescription'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card">
            <div class="card-header">Message</div>
            <div class="card-body">
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>

                <?php if($mess ?? '' != null): ?>
                <div class="alert alert-success">
                    <?php echo e($mess ?? ''); ?>

                </div>
                <?php endif; ?>

                <div>
                    <a href="/">Go to Home Page</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/application/message.blade.php ENDPATH**/ ?>