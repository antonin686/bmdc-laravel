<?php $__env->startSection('title', 'Complain'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mt-3">
        <div class="card">
            <div class="card-header card-header-bg">Complain</div>
            <div class="card-body">
                <div class="col">
                    
                    <div class="col-md-12">
                        
                        <hr>
                        <div class="h5">Complainer Info</div>
                        <hr>

                        <div class="row">
                            <div class="col-md-3"> Mr./Ms./Mrs. </div>

                            <div class="col-md-3">
                                [<?php echo e($citizen->first_name); ?> <?php echo e($citizen->last_name); ?>]
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3"> DOB </div>

                            <div class="col-md-3">
                                [<?php echo e($citizen->dob); ?>]
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3"> Address </div>

                            <div class="col-md-9">
                                [<?php echo e($citizen->current_address); ?>]
                            </div>
                        </div> 

                        <hr>
                        <div class="h5">Complain</div>
                        <hr>

                        <div class="row">
                            <div class="col-md-3"> <strong>Type</strong> </div>

                            <div class="col-md-9">
                                <?php echo e($complain->complain_type); ?>

                            </div>
                        </div> 
                        
                       
                        <div class="col-md-8 ml-0 pl-0">

                            <br>
                            <strong>Body:</strong>
                            <hr>
                            <p>
                                <?php echo nl2br($complain->complain_body); ?>

                            </p>
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/complain/show.blade.php ENDPATH**/ ?>