<?php $__env->startSection('title', 'Edit Medicine'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 mx-auto mt-3">
            <div class="card">
                <div class="card-header card-header-bg">Edit Medicine Profile</div>
                <div class="card-body">
                    <?php if(count($errors) > 0): ?>
                    <p class="alert alert-danger mb-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                    <?php endif; ?>
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                    <?php endif; ?>
                    <form method="POST" action=" <?php echo e(route('medicine.update', $medicine->id)); ?> ">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="form-group">
                            <label for="brand_name">Brand name</label>
                            <input type="text" class="form-control" name="brand_name" value="<?php echo e($medicine->brand_name); ?>">
                        </div>

                        <div class="form-group">
                            <label for="dosage_form">Dosage Form</label>
                            <input type="text" class="form-control" name="dosage_form"
                                value="<?php echo e($medicine->dosage_form); ?>">
                        </div>

                        <div class="form-group">
                            <label for="generic">Generic</label>
                            <select class="form-control" id="generic" name="generic">
                                <?php $__currentLoopData = $generics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $generic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($medicine->generic_id == $generic->id): ?>
                                <option value="<?php echo e($generic->id); ?>" selected="selected"><?php echo e($generic->generic_name); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($generic->id); ?>"><?php echo e($generic->generic_name); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="strength">Strength</label>
                            <input type="text" class="form-control" name="strength" value="<?php echo e($medicine->strength); ?>">
                        </div>

                        <div class="form-group">
                            <label for="company">Company</label>
                            <input type="text" class="form-control" name="company" value="<?php echo e($medicine->company); ?>">
                        </div>

                        <div class="form-group">
                            <label for="price">Price</label>
                            <input type="text" class="form-control" name="price" value="<?php echo e($medicine->price); ?>">
                        </div>

                        <button type="submit" class="btn btn-primary">Apply Changes</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/medicine/edit.blade.php ENDPATH**/ ?>