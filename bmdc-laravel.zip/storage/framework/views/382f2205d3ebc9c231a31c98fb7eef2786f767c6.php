<?php $__env->startSection('title', 'Generic Info'); ?>

<?php $__env->startSection('subcontent'); ?>
<div class="row">
    <div class="col-md-7 mt-3">

        <div title="Generic">
            <div class="h1 text-secondary mb-3 pb-3"><?php echo e($generic->generic_name); ?></div>
        </div>

        <a class="btn btn-info mb-3" href="<?php echo e(route('publicMedicine.genericBased', $generic->id)); ?>">View All Brand
            Names</a>
        <?php $__currentLoopData = $generic_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($value): ?>
        <div class="col-md-12 m-0 p-0">
            <div class=" mb-3 mt-3">
                <div class="card-header bg-secondary text-white"><?php echo e($key); ?></div>
                <div class="card-body">
                    <?php echo nl2br($value); ?>

                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="col-md-4 mt-3 ml-3">
        <div class="h2 text-black-50">Available Brand Names</div>
        <div class="row">
            <?php $__currentLoopData = $meds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12  mt-3">
                <div class="card-med">
                    <div class="card-body">
                        <a href="<?php echo e(route('publicMedicine.show', $med->id)); ?>">
                            <div class="h4 med-info">
                                <div class="text-dark"><?php echo e($med->brand_name); ?> <small> <?php echo e($med->strength); ?> </small></div>
                            </div>
                            <div class="h6 med-info">
                                <?php echo e($med->dosage_form); ?>

                                <div class="med-info text-primary"><?php echo e($med->company); ?></div>
                                <div class="med-info text-success">Unit Price: <?php echo e($med->price); ?></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medicine', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/public/medicine/generic/show.blade.php ENDPATH**/ ?>