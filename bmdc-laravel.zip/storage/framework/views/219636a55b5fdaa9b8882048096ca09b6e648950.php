<?php $__env->startSection('title', 'All Medicine'); ?>

<?php $__env->startSection('subcontent'); ?>
<div class="row my-2">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="h2 text-secondary">
                    Medicine List (A-Z)
                </div>
                <div class="row">
                    <?php $__currentLoopData = $meds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mt-4">
                        <div class="card-med">
                            <div class="card-body">
                                <a href="<?php echo e(route('publicMedicine.show', $med->id)); ?>">
                                    <div class="h3 med-info">
                                        <div class="text-dark"><?php echo e($med->brand_name); ?> <small> <?php echo e($med->strength); ?>

                                            </small></div>
                                    </div>
                                    <div class="h6 med-info">
                                        <?php echo e($med->dosage_form); ?> <br> <?php echo e($med->generic_name); ?>

                                        <div class="med-info text-primary"><?php echo e($med->company); ?></div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#table').DataTable();
    $('#table').on('click', 'tr', (event) => {
        var id = $(event.currentTarget).attr("id");
        if (id != null) {
            window.location.href = `/publicMedicine/${id}`;
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medicine', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/public/medicine/index.blade.php ENDPATH**/ ?>