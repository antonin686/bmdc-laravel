<?php $__env->startComponent('mail::message'); ?>
# Doctor Account Created

Congratulation <?php echo e($data->name); ?>, Your Account Has Been Created.

Your, <br>
Username: <?php echo e($data->username); ?> <br>
Password: <?php echo e($data->password); ?> 

<?php $__env->startComponent('mail::button', ['url' => $data->url ]); ?>
Download Your Software
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/emails/welcome.blade.php ENDPATH**/ ?>