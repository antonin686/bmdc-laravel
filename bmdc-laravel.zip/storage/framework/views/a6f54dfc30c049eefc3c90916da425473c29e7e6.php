<?php $__env->startSection('title', 'All medicine'); ?>

<?php $__env->startSection('subcontent'); ?>
<div class="row">
    <div class="col-md-12 mt-3">

        <div class="row">
            <div class="col-md-6">
                <div class="h3">
                    <?php echo e($medicine->brand_name); ?> <small title="Dosage Form"><?php echo e($medicine->dosage_form); ?></small>
                </div>
                <div title="Generic">
                    <a class="m-0 p-0" href="<?php echo e(route('publicMedicine.genericShow',$generic->id)); ?>">
                        <?php echo e($generic->generic_name); ?></a>
                </div>
                <div title="Strength" class="h5 text-secondary">
                    <?php echo e($medicine->strength); ?>

                </div>
                <div title="Company" class="h5 text-secondary">
                    <?php echo e($medicine->company); ?>

                </div>
                <div title="Price" class="h5 text-secondary">
                    Unit Price: ৳ <?php echo e($medicine->price); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="card"> 
                    <img src="<?php echo e($medicine->img_path); ?>" height="200px" class="card-img-top" alt="medicine image">
                </div>
            </div>

        </div>

        <?php $__currentLoopData = $generic_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($value): ?>
        <div class="col-md-12 m-0 p-0">
            <div class="card mb-3 mt-3">
                <div class="card-body bg-dark text-white"><?php echo e($key); ?></div>
                <div class="card-body">
                    <?php echo e($value); ?>

                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.medicine', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/public/medicine/show.blade.php ENDPATH**/ ?>