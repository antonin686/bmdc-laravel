<?php $__env->startSection('title', 'Doctor Info'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mx-auto mt-3">
        <div class="card">
            <div class="card-header card-header-bg">Doctor Info</div>
            <div class="card-body">

                <div class="row">
                    <div class="col-md-8">
                        <div class="card card-body">
                            <table class="table" id="table">
                                <tbody>
                                    <tr class="bg-dark text-light">
                                        <th>#</th>
                                        <td><?php echo e($doc->registration_id); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Name</th>
                                        <td><?php echo e($doc->full_name); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Speciality</th>
                                        <td><?php echo e($doc->speciality); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Place Of Work</th>
                                        <td> <?php echo e($doc->work_place); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Degree</th>
                                        <td> <?php echo e($doc->basic_degree); ?>,  <?php echo e($doc->advance_degree); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Phone</th>
                                        <td> <?php echo e($doc->phone); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Email</th>
                                        <td> <?php echo e($doc->email); ?></td>
                                    </tr>                       
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <img src="<?php echo e($doc->img_path); ?>" class="card-img-top" alt="img">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <a href="<?php echo e(route('doctor.edit', $doc->id )); ?>" class="btn btn-info m-3">Edit Profile</a>
                    <form class="m-3" action="<?php echo e(route('doctor.destroy', $doc->id )); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/doctor/show.blade.php ENDPATH**/ ?>