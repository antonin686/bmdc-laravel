<?php $__env->startSection('title', 'Message'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header">Message</div>
            <div class="card-body">
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>

                <div class="row m-0 p-0">    
                    <div class="col-md-3  mt-2">
                        <a class="btn btn-info" href="<?php echo e(route('doctor.show', session()->get('id'))); ?>">Doctor Profile</a>
                    </div>

                    <div class="col-md-3 mt-2">
                        <a class="btn btn-primary" href="<?php echo e(route('doctor.index')); ?>">Doctor List</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/doctor/message.blade.php ENDPATH**/ ?>