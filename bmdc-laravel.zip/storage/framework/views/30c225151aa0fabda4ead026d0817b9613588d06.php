<?php $__env->startSection('title', 'Edit Doctor'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 mx-auto mt-3">
            <div class="card">
                <div class="card-header card-header-bg">Edit Doctor Profile</div>
                <div class="card-body">
                    <?php if(count($errors) > 0): ?>
                    <p class="alert alert-danger mb-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                    <?php endif; ?>
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="row">

                        <div class="col-md-8">
                            <form class="px-3" method="POST" action=" <?php echo e(route('doctor.update', $doc->id)); ?> ">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>

                                <div class="form-group ">
                                    <label for="username">Username</label>
                                    <input type="text" class="form-control" name="username" value="<?php echo e($doc->username); ?>"
                                        readonly>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="nid">NID</label>
                                        <input type="text" class="form-control" name="nid" value="<?php echo e($doc->nid); ?>">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="registration_id">Registration Number</label>
                                        <input type="text" class="form-control" name="registration_id"
                                            value="<?php echo e($doc->registration_id); ?>" readonly>
                                    </div>
                                </div>

                                <div class="form-group ">
                                    <label for="full_name">Full Name</label>
                                    <input type="text" class="form-control" name="full_name"
                                        value="<?php echo e($doc->full_name); ?>">
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="email">Email</label>
                                        <input type="email" class="form-control" name="email" value="<?php echo e($doc->email); ?>">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="phone">Phone</label>
                                        <input type="text" class="form-control" name="phone" value="<?php echo e($doc->phone); ?>">
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="basic_degree">Basic basic_degree</label>
                                        <input type="text" class="form-control" name="basic_degree"
                                            value="<?php echo e($doc->basic_degree); ?>">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="advance_degree">Advance Degree</label>
                                        <input type="text" class="form-control" name="advance_degree"
                                            value="<?php echo e($doc->advance_degree); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="speciality">Speciality</label>
                                    <input type="text" class="form-control" name="speciality"
                                        value="<?php echo e($doc->speciality); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="work_place">Work Place</label>
                                    <input type="text" class="form-control" name="work_place"
                                        value="<?php echo e($doc->work_place); ?>">
                                </div>

                                <button type="submit" class="btn btn-primary">Apply Changes</button>

                            </form>
                        </div>
                        <div class="col md-4 mt-3">
                            <div class="card">
                                <img src="<?php echo e($doc->img_path); ?>" class="card-img-top" alt="img">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/doctor/edit.blade.php ENDPATH**/ ?>