<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-3 pt-3">
    <div class="col-md-4 mt-4">
        <div class="card card-hover shadow">
            <div class="card-body bg-primary-light">
                <a href=" <?php echo e(route('doctor.index')); ?> ">
                    <div class="h1">
                        <i class="fas fa-user-md text-light"></i>
                    </div>
                    <div class="row">
                        <div class="mr-auto ml-2 display-5 text-light">
                            DOCTORS
                        </div>
                        <div class="ml-auto text-light mr-2 h5">
                            <strong> <span id="card-doctor" class="badge badge-primary badge-pill">0</span></strong>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-4 mt-4">
        <div class="card card-hover shadow">
            <div class="card-body bg-danger-light">
                <a href=" <?php echo e(route('medicine.index')); ?>">
                    <div class="h1">
                        <i class="fas fa-pills text-light"></i>
                    </div>
                    <div class="row">
                        <div class="mr-auto ml-2 display-5 text-light">
                            Medicines
                        </div>
                        <div class="ml-auto text-light mr-2 h5">
                            <strong> <span id="card-medicine" class="badge badge-danger badge-pill">0</span></strong>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-4 mt-4">
        <div class="card card-hover shadow">
            <div class="card-body bg-success-light">
                <a href=" <?php echo e(route('generic.index')); ?> ">
                    <div class="h1">
                        <i class="fas fa-flask text-light"></i>
                    </div>
                    <div class="row">
                        <div class="mr-auto ml-2 display-5 text-light">
                            Generics
                        </div>
                        <div class="ml-auto text-light mr-2 h5">
                            <strong> <span id="card-generic" class="badge badge-success badge-pill">0</span></strong>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-4 mt-4">
        <div class="card card-hover shadow">
            <div class="card-body bg-info-light">
                <a href="<?php echo e(route('prescription.index')); ?>">
                    <div class="h1">
                        <i class="fas fa-file-prescription text-light"></i>
                    </div>
                    <div class="row">
                        <div class="mr-auto ml-2 display-5 text-light">
                            Prescriptions <br>
                            <div class="text-white-50">Today</div>
                        </div>
                        <div class="ml-auto text-light mt-2 mr-2 h5">
                            <strong> <span id="card-presc" class="badge badge-info badge-pill">0</span></strong>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-4 mt-4">
        <div class="card card-hover shadow">
            <div class="card-body bg-warning-light">
                <a href="<?php echo e(route('application.doctorApplicationIndex')); ?>">
                    <div class="h1">
                        <i class="fas fa-portrait text-light"></i>
                    </div>
                    <div class="row">
                        <div class="mr-auto ml-2 display-5 text-light">
                            Doctor <br> Applications
                        </div>
                        <div class="ml-auto text-light mt-2 mr-2 h5">
                            <strong> <span id="card-doctor-application"
                                    class="badge badge-warning text-light badge-pill">0</span>
                            </strong>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-4 mt-4">
        <div class="card card-hover shadow">
            <div class="card-body bg-purple-light">
                <a href="<?php echo e(route('application.medicineApplicationIndex')); ?>">
                    <div class="h1">
                        <i class="fas fa-file-medical text-light"></i>
                    </div>
                    <div class="row">
                        <div class="mr-auto ml-2 display-5 text-light">
                            Medicine <br> Applications
                        </div>
                        <div class="ml-auto text-light mt-2 mr-2 h5">
                            <strong> <span id="card-medicine-application"
                                    class="badge bg-purple text-light badge-pill">0</span>
                            </strong>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    adminHomeCounts();

    function adminHomeCounts() {

        $.ajax({
            url: "<?php echo e(route('ajax.adminHomeCounts')); ?>",
            method: "GET",
            dataType: "json",
            success: function(result) {
                $('#card-doctor').html(result[0]);
                $('#card-medicine').html(result[1]);
                $('#card-generic').html(result[2]);
                $('#card-presc').html(result[3]);
                $('#card-doctor-application').html(result[4]);
                $('#card-medicine-application').html(result[5]);
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/admin/home.blade.php ENDPATH**/ ?>