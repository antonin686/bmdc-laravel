<?php $__env->startComponent('mail::message'); ?>
# Medicine Approved

Congratulation <?php echo e($data->name); ?>, Your Medicine Has Been Approved.

<?php $__env->startComponent('mail::button', ['url' => $data->url ]); ?>
Check Your Medicine
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/emails/approvedMedicine.blade.php ENDPATH**/ ?>