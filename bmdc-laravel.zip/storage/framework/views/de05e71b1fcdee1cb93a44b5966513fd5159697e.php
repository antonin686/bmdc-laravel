<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <div class="card">
        <div class="card-header card-header-bg">Medicine Application Profile</div>
        <div class="card-body py-3">
            <?php if(count($errors) > 0): ?>
            <p class="alert alert-danger mb-3">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <?php endif; ?>
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <form method="POST" action=" <?php echo e(route('application.medicine.medstore', $medicine->id)); ?> ">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-8">
                        <input type="hidden" name="img_path" value="<?php echo e($medicine->img_path); ?>">

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="brand_name">Brand name</label>
                                <input type="text" class="form-control" name="brand_name"
                                    value="<?php echo e($medicine->brand_name); ?>">
                            </div>

                            <div class="form-group col-md-6">
                                <label for="generic">Generic</label>
                                <select class="form-control" id="generic" name="generic">

                                    <?php $__currentLoopData = $generics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $generic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($medicine->generic_id == $generic->id): ?>
                                    <option value="<?php echo e($generic->id); ?>" selected="selected"><?php echo e($generic->generic_name); ?>

                                    </option>
                                    <?php else: ?>
                                    <option value="<?php echo e($generic->id); ?>"><?php echo e($generic->generic_name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="dosage_form">Dosage Form</label>
                                <input type="text" class="form-control" name="dosage_form"
                                    value="<?php echo e($medicine->dosage_form); ?>">
                            </div>

                            <div class="form-group col-md-6">
                                <label for="strength">Strength</label>
                                <input type="text" class="form-control" name="strength" value="<?php echo e($medicine->strength); ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="company">Company</label>
                                <input type="text" class="form-control" name="company" value="<?php echo e($medicine->company); ?>">
                            </div>

                            <div class="form-group col-md-6">
                                <label for="price">Price</label>
                                <input type="text" class="form-control" name="price" value="<?php echo e($medicine->price); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="applicant_name">Applicant Name</label>
                            <input type="text" class="form-control" name="applicant_name"
                                value="<?php echo e($medicine->applicant_name); ?>">
                        </div>

                        <div class="form-group">
                            <label for="applicant_email">Applicant Email</label>
                            <input type="email" class="form-control" name="applicant_email"
                                value="<?php echo e($medicine->applicant_email); ?>">
                        </div>

                        <div class="form-group">
                            <label for="applicant_phone">Applicant Phone</label>
                            <input type="text" class="form-control" name="applicant_phone"
                                value="<?php echo e($medicine->applicant_phone); ?>">
                        </div>
                    </div>

                    <div class="col-md-4 ">
                        <div class="card">
                            <img src="<?php echo e($medicine->img_path); ?>" class="card-img-top" alt="img">

                        </div>
                    </div>

                </div>




                <button type="submit" class="btn btn-primary">Approve Medicine</button>
                <a class="btn btn-danger" href="<?php echo e(route('application.medicine.destroy', $medicine->id)); ?>">Reject</a>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/application/medicine/show.blade.php ENDPATH**/ ?>