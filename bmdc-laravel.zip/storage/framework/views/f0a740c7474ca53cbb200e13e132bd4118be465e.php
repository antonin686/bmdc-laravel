<?php $__env->startComponent('mail::message'); ?>
# Hello <?php echo e($data->name); ?> ,

You have applied for doctor authorization <br>
Please click the verify email button to verify your email

<?php $__env->startComponent('mail::button', ['url' => $data->url ]); ?>
Verify Email
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/emails/emailVerificationMail.blade.php ENDPATH**/ ?>