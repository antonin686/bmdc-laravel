<?php $__env->startSection('title', 'All Generic'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mx-auto mt-3">
        <div class="card">
            <div class="card-header card-header-bg">Generic List</div>
            <div class="card-body">
                <div class="row mx-auto">
                <a class="btn btn-primary m-3" href="<?php echo e(route('generic.create')); ?>">Add New Generic</a>
                </div>
                <div class="card card-body">
                    <table class="table table-striped table-responsive-sm table-hover" id="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Generic Name</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $generics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $generic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="<?php echo e($generic->id); ?>">
                                <td><?php echo e($generic->id); ?></td>
                                <td><?php echo e($generic->generic_name); ?></td>
                                <td>
                                    <div class="row">
                                    <a title="Details" class="btn btn-info mr-1" href="<?php echo e(route('generic.show', $generic->id)); ?>"> <i
                                            class="fas fa-info"></i> </a>
                                    <a title="Edit" class="btn btn-primary mr-1" href="<?php echo e(route('generic.edit', $generic->id)); ?>"> <i
                                            class="fas fa-pen-alt"></i> </a>
                                    <!-- <form action="<?php echo e(route('generic.destroy', $generic->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger" type="submit"><i class="fas fa-trash"></i></button>
                                    </form> -->
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#table').DataTable();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/medicine/generic/index.blade.php ENDPATH**/ ?>