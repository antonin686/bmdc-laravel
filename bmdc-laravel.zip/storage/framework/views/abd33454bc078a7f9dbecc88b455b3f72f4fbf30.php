<?php $__env->startSection('title', 'All medicine'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mt-3">
        <div class="card">
            <div class="card-header card-header-bg">Prescription</div>
            <div class="card-body">
                <div class="col">
                    <div class="col-md-12">
                        <div title="Hospital Name" class="h1 mx-auto"><i class="fas fa-clinic-medical text-success"></i>
                            <?php echo e($prescription->hospital_name); ?>

                        </div>
                        <hr>
                    </div>
                    <div class="col-md-12">
                        <div class="h5"> Doctor Info</div>
                        <hr>
                        <div class="row">
                            <div title="Name" class="col-md-6">
                                <span class="mr-2 text-info">
                                    <i class="fas fa-user-md"></i>
                                </span>
                                [ <a href="<?php echo e(route('doctor.show', $doctor->id)); ?>">
                                    <?php echo e($doctor->full_name); ?>

                                </a> ]
                            </div>
                            <div title="Speciality" class="col-md-6">
                                <span class="mr-2 text-info">
                                    <i class="fas fa-certificate"></i>
                                </span> [ <?php echo e($doctor->speciality); ?> ]
                            </div>
                        </div>

                        <div class="row">
                            <div title="Degree" class="col-md-12">
                                <span class="text-info mr-1">
                                    <i class="fas fa-graduation-cap"></i>
                                </span>
                                [ <?php echo e($doctor->basic_degree); ?>, <?php echo e($doctor->advance_degree); ?> ]
                            </div>
                        </div>

                        <div class="row">
                            <div title="email" class="col-md-6">
                                <span class="mr-2 text-info">
                                    <i class="fas fa-at"></i>
                                </span> [ <?php echo e($doctor->email); ?> ]
                            </div>

                            <div title="phone" class="col-md-6">
                                <span class="mr-2 text-info">
                                    <i class="fas fa-phone-alt"></i>
                                </span> [ <?php echo e($doctor->phone); ?> ]
                            </div>
                        </div>

                        <hr>
                        <div class="h5">Patient Info</div>
                        <hr>

                        <div class="row">
                            <div class="col-md-3"> Mr./Ms./Mrs. </div>

                            <div class="col-md-3">
                                [<?php echo e($citizen->first_name); ?> <?php echo e($citizen->last_name); ?>]
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3"> Age </div>

                            <div class="col-md-3">
                                [<?php echo e($citizen->age); ?>]
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3"> Address </div>

                            <div class="col-md-9">
                                [<?php echo e($citizen->current_address); ?>]
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3"> Prescription ID </div>

                            <div class="col-md-9">
                                [<?php echo e($prescription->id); ?>]
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3"> Date </div>

                            <div class="col-md-9">
                                [<?php echo e($prescription->date); ?>]
                            </div>
                        </div>

                        <hr>
                        <div class="h5">Prescription</div>
                        <hr>

                        <div class="col ml-0 pl-0">
                            <div class="col-md-6 ml-0 pl-0">
                                <strong>Disease</strong>: <?php echo e($prescription->disease); ?>

                            </div>

                            <div class="col-md-6 ml-0 pl-0">
                                <strong>OE</strong>: <?php echo e($prescription->oe); ?>

                            </div>

                            <div class="col-md-6 ml-0 pl-0">
                                <strong>LX</strong>: <?php echo e($prescription->lx); ?>

                            </div>

                            <div class="col-md-6 ml-0 pl-0">
                                <strong>CC</strong>: <?php echo e($prescription->cc); ?>

                            </div>
                        </div>

                        <div class="col-md-8 ml-0 pl-0">

                            <hr>
                            <strong>Body:</strong>
                            <hr>
                            <p>
                                <?php echo nl2br($prescription->mainbody); ?>

                            </p>
                            <?php if($prescription->revisit): ?>
                            <div class="text-center text-danger">Revisit in <?php echo e($prescription->revisit); ?> Days</div>
                            <?php else: ?>
                            <div class="text-center text-success">Best Wishes, Get Well Soon</div>    
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/prescription/show.blade.php ENDPATH**/ ?>