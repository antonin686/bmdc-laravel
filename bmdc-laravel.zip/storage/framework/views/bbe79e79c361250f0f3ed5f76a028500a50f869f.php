<?php $__env->startSection('title', 'All Doctor Modifies'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mx-auto mt-3">
        <div class="card">
            <div class="card-header card-header-bg">Doctor Profile Update Request List</div>
            <div class="card-body">
                <div class="card card-body">
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                    <?php endif; ?>
                    <table class="table table-hover table-responsive-sm" id="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Speciality</th>
                                <th scope="col">Degree</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="<?php echo e($doctor->id); ?>">
                                <td><?php echo e($doctor->id); ?></td>
                                <td><?php echo e($doctor->full_name); ?></td>
                                <td><?php echo e($doctor->speciality); ?></td>
                                <td><?php echo e($doctor->basic_degree); ?>, <?php echo e($doctor->advance_degree); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#table').DataTable();
    $('#table').on('click', 'tr', (event) => {
        var id = $(event.currentTarget).attr("id");
        if (id != null) {
            window.location.href = `/admin/doctorModify/${id}`;
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bmdc-laravel\resources\views/doctor/modify/index.blade.php ENDPATH**/ ?>