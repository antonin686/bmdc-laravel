@extends('layouts.public')

@section('content')
<div class="row">
    <div class="display-1 text-secondary center-screen mx-auto">
        <div class="row">
            BMDC<div class="display-4 mt-4">(Prototype)</div>
        </div>

    </div>
</div>
@endsection